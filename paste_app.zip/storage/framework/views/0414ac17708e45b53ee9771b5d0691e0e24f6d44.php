<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                margin: 15px;
            }



        </style>
    </head>
    <body>
        <div>
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>


             
            <br>
            <form action = "/submit" method = "get">
                <button type = "submit">
                    new paste 
                </button> 
            </form>
            <br>



            <div class="content">
                <div class="title">
                    <h3> Click title to view paste data </h3>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Paste</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                            </tr>
                        </thead>
                </div>
                    <tbody>
                
                    
                    <?php $__currentLoopData = $pastas->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i->id); ?></td>
                                <td>
                                    <a href = "/view_paste/<?php echo e($i->id); ?>">
                                            <?php echo e($i->title); ?>

                                    </a>
                                </td>
                                <td><?php echo e(substr($i->paste_data, 0, 50)); ?></td> 
                                <td><?php echo e($i->created_at); ?></td>
                                <td><?php echo e($i->updated_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
<?php /**PATH E:\program\projects\links\resources\views/welcome.blade.php ENDPATH**/ ?>